#!/data/data/com.termux/files/home/kali-armhf/root
#Created on 3/8/2018 by Mohammed Info

apt-get update && apt-get upgrade -y

apt-get install python python2 python3 python-dev gem python-pip git wget curl perl ruby proot figlet apache2 -y

apt-get install lxde-core lxde kali-defaults kali-root-login desktop-base -y

apt-get install metasploit-framework -y

apt-get install armitage -y

rm -r /usr/share/metasploit-framework/config

mv $HOME/M.Info-Kali-Nethunter/config /usr/share/metasploit-framework/
rm -r /usr/var
mv $HOME/M.Info-Kali-Nethunter/var /usr
rm -r /usr/share/postgresql && rm -r /usr/share/postgresql-common
mv $HOME/M.Info-Kali-Nethunter/postgresql /usr/share/

rm -r $HOME/M.Info-Kali-Nethunter
